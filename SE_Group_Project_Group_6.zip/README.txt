Run the MBS.py, it is the main

make sure you have numpy, if you dont run this in your cmd "pip install numpy"